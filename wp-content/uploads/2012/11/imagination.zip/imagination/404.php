<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>

<div class="post curved pngfix">
<h2 class="center">Error 404 - Not Found</h2>
<p>
	Unfortunately you have stumbled across a page that doesn't exist.
</p>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>