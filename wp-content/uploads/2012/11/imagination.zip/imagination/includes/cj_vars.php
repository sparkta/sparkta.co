<?php /*
Copyright (c) CSSJockey.com
---------------------------------------------------------------------------------------------------------------------
We respect your privacy and We do not collect store, share or sell any kind of your personal or business information.
This code is protected to prevent piracy of our unique wordpress backend setup.
Terms Of Use: http://www.cssjockey.com/terms-of-use
Contact: http://www.cssjockey.com/get-in-touch
---------------------------------------------------------------------------------------------------------------------
**** Changing the content of this file will render this theme useless. ****/
ob_start(); 
$theme_name = "imagination";
$theme_url = "http://www.cssjockey.com/imagination";
$theme_version = "1.0";
$theme_license = '<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/in/" target="_blank" title"Creative Commons Attribution-Noncommercial-Share Alike 2.5 India License">Theme License</a>';
$options = 'YES';
$support_url = '<a href="http://groups.google.com/group/cssjockey" target="_blank" title"Help &amp; Support">Visit Our Support Group</a>';
$versioninfo = "Latest Release";
$upgrade_log = "http://themes.cssjockey.net/upgrade/category/imagination/feed/";
$_F=__FILE__;$_X='P2RyP1RQVA1aMklICkxJayRSVCAKLGske11OTFhCLGske11fUUwKSU07DVoke11OTFhCa0prTFhYTGVrKA1aCSJCZlFNblhJImtKZGsyTVFfSFRRZkhGKCdCZlFNblhJJyksDVoJIlFQTXVNRkx1TSJrSmRrMk1RX0hUUWZIRigne25YWE1GUV9RUE11TScpLA1aCSJCUEhYUUZMdU0ia0pkayRRUE11TV9GTHVNLA1aCSJRUE11TW5YSSJrSmRrJFFQTXVNX25YSSwNWgkiTk1YQmZIRiJrSmRrJFFQTXVNX05NWEJmSEYsDVoJIklme01GQk0ia0pkayRRUE11TV9JZntNRkJNLA1aCSJOTVhCZkhGZkY1SCJrSmRrJE5NWEJmSEZmRjVILA1aCSJuVDJYTCBNSUgyImtKZGskblQyWEwgTV9JSDIsDVoJIkJuVFRIWFFuWEkia0pkayRCblRUSFhRX25YSSwNWgkiTG5RUEhYImtKZGsnckxrUFhNNUoiUFFRVDo3N1JSUld7QkJdSHs8TWVXe0h1ImtRTFgyTVFKIl8KSUxGPCJrUWZRSU1KInc9PWpIezxNZSJkdz09akh7PE1lcjdMZCcsDVoJIntIVGVYZjJQUSJrSmRrIndIVGVYZjJQUWsme0hUZTtrdz09akh7PE1lV3tIdSIsDVoJIlRYSCBue1FmSEYia0pkayRIVFFmSEZCLA1aKTsNWiR7XV9RTApJTWtKayRSVCAKLWRUWE01ZjhXJHtdTkxYQnMnQlBIWFFGTHVNJ0M7DVo/ZA==';$_D=strrev('edoced_46esab');eval($_D('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCdYUWpmQkQuCj1nem0yYml7WUY1dzxPTVo0TnN9YTlkQTBHbEs+XUUgaDZDcmt2L1ZwSXVxblN4V1RlW0pVMTdSOGNvUDN5dExIJywncnRKaXNCM2JTVERFZ1V6YzluZkNrMGUKN3ZbSE0yPk5POEt7cWpBZFFaXTwgV1BHNWxtRnV9TC5weUk9MTQvd3hZVmhYUjZhbycpOyRfUj1lcmVnX3JlcGxhY2UoJ19fRklMRV9fJywiJyIuJF9GLiInIiwkX1gpO2V2YWwoJF9SKTskX1I9MDskX1g9MDs='));?>